﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopCartApp.Models
{
    public class ViewPurchaseModel
    {
        //public string ActCode { get; set; }
        public string ProductName { get; set; }
        public string ProductDesc { get; set; }
        public long PurchasedDate { get; set; }
        public string ProductImageLink { get; set; }
        public int Count { get; set; }
        public List<string> ActCode { get; set; }

    }
}