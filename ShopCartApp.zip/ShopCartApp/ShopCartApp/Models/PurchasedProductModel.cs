﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopCartApp.Models
{
    public class PurchasedProductModel
    {
        public string ActCode { get; set; }
        public int ProductId { get; set; }
        public int UserId { get; set; }
        public int Date { get; set; }

        public PurchasedProductModel(string actCode, int productId, int userId, int date)
        {
            ActCode = actCode;
            ProductId = productId;
            UserId = userId;
            Date = date;
        }
    }
}