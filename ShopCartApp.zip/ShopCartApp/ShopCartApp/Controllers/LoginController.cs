﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShopCartApp.Models;
using ShopCartApp.DB;

namespace ShopCartApp.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        [Route("Login")]
        public ActionResult Login(string Username, string password)
        {
            if (Username == null)
            {
                return View();
            }

            LoginCred user = ShopperData.GetLoginCred(Username);

            if (user == null || user.Password != password)
            {
                return View();
            }

            string sessionId = SessionData.CreateSession(user.Username);

            return RedirectToAction("ViewGallery", "Gallery", new { sessionId });
        }
    }
}