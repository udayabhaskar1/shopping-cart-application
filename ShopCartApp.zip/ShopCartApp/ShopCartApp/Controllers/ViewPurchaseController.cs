﻿using ShopCartApp.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShopCartApp.Filters;

namespace ShopCartApp.Controllers
{
    public class ViewPurchaseController : Controller
    {
        // GET: ViewPurchase
        [Route("ViewPurchase")]
        [PersonalFilter]
        public ActionResult ViewPurchase(string SessionId)
        {
            ViewData["SessionId"] = SessionId;
            int userId = ShopperData.GetShopperId(SessionId);
            ViewData["purchases"] = ViewPurchaseData.GetPurchaseModel(userId);

            return View();
        }
    }
}