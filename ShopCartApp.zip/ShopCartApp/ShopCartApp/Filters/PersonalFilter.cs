﻿using ShopCartApp.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace ShopCartApp.Filters
{
        public class PersonalFilter : ActionFilterAttribute, IAuthorizationFilter
        {
            public void OnAuthorization(AuthorizationContext context)
            {
                string sessionId = HttpContext.Current.Request["SessionID"];

                if (!SessionData.IsActiveSessionId(sessionId))
                {
                    context.Result = new RedirectToRouteResult(
                        new RouteValueDictionary
                        {
                            {"controller","Login" },
                            {"action", "Login" }
                        }
                );
            }
        }
    }
}