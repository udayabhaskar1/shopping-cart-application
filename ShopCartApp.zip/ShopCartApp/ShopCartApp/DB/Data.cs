﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopCartApp.DB
{
    public class Data
    {
        public static string connectionString = "Server=LAPTOP-6BSJ1Q83;" + "Database=ShopCart;" + "Integrated Security=true";
    }
}