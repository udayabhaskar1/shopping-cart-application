﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CA.Models
{
    public class Login
    {
        [Remote("CheckUserName","Login", HttpMethod ="POST", ErrorMessage ="Incorrect Username")]
        [Required(ErrorMessage ="Username is required")]
        [Display(Name = "Username:")]
        public string Username { get; set; }

        [Remote("CheckPassword", "Login", HttpMethod ="POST", ErrorMessage ="Incorrect Password")]
        [Required(ErrorMessage ="Password is required")]
        [Display(Name= "Password:")] 
        public string Password { get; set; }
    }
}