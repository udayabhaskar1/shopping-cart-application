﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CA.Models;
using System.Diagnostics;
using CA.DB;

namespace CA.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index(string Username, string password)
        {
            if(Username == null)
            return View();

            User user = UserData.GetUserByUsername(Username);
            
            if (user.Password != password)
                return View();

            string sessionId = SessionData.CreateSession(user.UserId);
            
            return RedirectToAction("ViewProduct", "Product", new { sessionId });
        }

        public ActionResult CheckUserName(string Username)
        {
            if (User == null)
            {
                return Json(false);
            }
            return Json(true);
        }

        public ActionResult CheckPassword(string Password)
        {
            if (User == null)
            {
                return Json(false);
            }
            return Json(true);
        }

    }
}