﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Diagnostics;
using CA.Models;

namespace CA.DB
{
    public class UserData:Data
    {
        public static User GetUserByUsername(String username)
        {
            User user = null;
            using (SqlConnection conn = new SqlConnection(Data.connectionString))
            {
                conn.Open();
                string sql = @"SELECT UserId, UserName, Password, SessionId from Shopper WHERE FirstName = '" + username + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                
                SqlDataReader reader = cmd.ExecuteReader();
                if(reader.Read())
                {
                    user = new User()
                    {
                        UserId = (int)reader["Id"],
                        Password = (string)reader["Password"]
                    };
                }
            }
            return user;
        }
    }
}