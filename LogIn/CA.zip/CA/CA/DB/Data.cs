﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CA.DB
{
    public class Data
    {
        public static string connectionString = "Server=Desktop-9M1l2l4;" + "Database=ShopCart; Integrated Security= true";
    }//RETYPE YOUR SERVER
}