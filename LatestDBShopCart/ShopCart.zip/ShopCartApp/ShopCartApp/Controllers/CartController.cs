﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShopCartApp.Models;
using ShopCartApp.DB;
using ShopCartApp.Filters;

namespace ShopCartApp.Controllers
{
    public class CartController : Controller
    {
        // GET: Cart
        [Route("Cart")]
        [PersonalFilter]
        public ActionResult ViewCart(string SessionId)
        {
            List<CartModel> carts = CartData.GetCartDetails();
            ViewData["carts"] = carts;
            ViewData["SessionId"] = SessionId;
            return View();
        }
        public ActionResult UpdateQty(int qty, int prodId, string SessionId)
        {
            CartData.UpdateCart(qty, prodId);
            ViewData["SessionId"] = SessionId;
            return RedirectToAction("ViewCart", "Cart", new { SessionId});
        }
        public ActionResult SetOrder(string SessionId)
        {
            PurchaseProductData.SetPurchase(SessionId);
            return RedirectToAction("ViewPurchase", "ViewPurchase", new { SessionId });
        }
    }
}