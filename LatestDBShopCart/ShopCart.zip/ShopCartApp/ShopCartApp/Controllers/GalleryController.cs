﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShopCartApp.DB;
using ShopCartApp.Filters;

namespace ShopCartApp.Controllers
{
    public class GalleryController : Controller
    {
        // GET: Gallery
        [Route("Gallery")]
        [PersonalFilter]
        public ActionResult ViewGallery(string str, string SessionId)
        {
            ViewData["products"] = ProductData.GetProductDetails();
            ViewData["searchterm"] = str;
            ViewData["SessionId"] = SessionId;
            ViewData["productbundle"] = ProductData.GetProductBundle();
            return View();
        }
        public ActionResult AddItem(int id, string SessionId)
        {
            ProductData.AddItemToCart(id);
            return RedirectToAction("ViewGallery", new { SessionId });
        }
    }
}