﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopCartApp.Utils
{
    public static class StringExtensions
    {
        public static bool Contains(this String str, String substring, StringComparison comp)
        {
            if (substring == null)
            {
                substring = "";
                //throw new ArgumentNullException("substring", "substring cannot be null.");
            }
            else if (!Enum.IsDefined(typeof(StringComparison), comp))
                throw new ArgumentException("comp is not a member of StringComparison", "comp");

            return str.IndexOf(substring, comp) >= 0;
        }

    }
}