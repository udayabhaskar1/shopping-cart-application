﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using ShopCartApp.Models;

namespace ShopCartApp.DB
{
    public class ViewPurchaseData : Data
    {
        public static List<ViewPurchaseModel> GetPurchaseModel(int userId)
        {
            List<ViewPurchaseModel> purchases = new List<ViewPurchaseModel>();
            ViewPurchaseModel vtemp = new ViewPurchaseModel //set to be different from the first element
            {
                ActCode = new List<string>(),
                ProductName = "",
                ProductDesc = "",
                PurchasedDate = 0,
                ProductImageLink = "",
                Count = 1
            };
            purchases.Add(vtemp);   //Added to make sure the list reference is not null
            int index = 0;  //For referring to positions in a list
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                //String Command used for pulling necessary data from model. Modification needed to adjust it to the user
                string cmdText = @"select ActCode, ProductName, ProductDesc, PurchasedDate, ProductImageLink
                                from PurchasedProduct pp, Shopper s, Product p
                                where pp.UserId ='"+ userId +@"' AND pp.UserId = s.UserId AND pp.ProductId = p.ProductId
                                order by pp.ProductId";

                SqlCommand cmd = new SqlCommand(cmdText, conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    ViewPurchaseModel v = new ViewPurchaseModel
                    {
                        ActCode = vtemp.ActCode,
                        ProductName = (string)sdr["ProductName"],
                        ProductDesc = (string)sdr["ProductDesc"],
                        PurchasedDate = (long)sdr["PurchasedDate"],
                        ProductImageLink = (string)sdr["ProductImageLink"],
                        Count = vtemp.Count
                    };
                    if (v.ProductName == vtemp.ProductName && v.PurchasedDate == vtemp.PurchasedDate)
                    {
                        purchases.ElementAt(index).ActCode.Add((string)sdr["ActCode"]);
                        purchases.ElementAt(index).Count++;
                    }
                    else
                    {
                        v.ActCode.Add((string)sdr["ActCode"]);
                        purchases.Add(v);
                        vtemp.ActCode = new List<string>();
                        vtemp.ProductName = v.ProductName;
                        vtemp.ProductDesc = v.ProductDesc;
                        vtemp.PurchasedDate = v.PurchasedDate;
                        vtemp.ProductImageLink = v.ProductImageLink;
                        vtemp.Count = 1;
                        index++;
                    }
                }
            }
            purchases.RemoveAt(0);  //After preparing the list, the empty placeholder object is no longer needed
            return purchases;
        }
    }
}