﻿using ShopCartApp.Models;
using ShopCartApp.Utils;
using ShopCartApp.DB;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ShopCartApp.DB
{
    public class PurchaseProductData : Data
    {
        public static void SetPurchase(string SessionId)
        {
            List<PurchasedProductModel> newPurchase = new List<PurchasedProductModel>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string cmdText = @"SELECT c.ProductId, c.Quantity, s.UserId FROM Cart c, Shopper s WHERE c.SessionId ='" + SessionId + "' AND s.SessionId = '" + SessionId + "'";
                SqlCommand cmd = new SqlCommand(cmdText, conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    for (int x = 0; x < (int)sdr["Quantity"]; x++)
                    {
                        PurchasedProductModel p = new PurchasedProductModel();
                        p.ActCode = Guid.NewGuid().ToString();
                        p.ProductId = (int)sdr["ProductId"];
                        p.Date = Timestamp.unixTimestamp();
                        p.UserId = (int)sdr["UserID"];
                        newPurchase.Add(p);
                    }
                }  
            }
            WriteInto(newPurchase);
            CartData.EmptyCart(SessionId);
        }
        public static void WriteInto(List<PurchasedProductModel> newp)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                foreach (PurchasedProductModel p in newp)
                {
                    string cmdTextvar = @"INSERT INTO PurchasedProduct(ActCode, ProductId, UserId, PurchasedDate)
                                        VALUES('" + p.ActCode + "'," + p.ProductId + "," + p.UserId + "," + p.Date + ")";
                    SqlCommand update = new SqlCommand(cmdTextvar, conn);
                    update.ExecuteNonQuery();
                }
            }
        }
    }
}