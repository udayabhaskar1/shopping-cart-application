﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopCartApp.Models
{
    public class ProductBundle
    {
        public int CartSize { get; set; }
        public List<ProductModel> Products { get; set; }
    }
}