﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ShopCartApp.Models;

namespace ShopCartApp.DB
{
    public class ShopperData : Data
    {
        public static LoginCred GetLoginCred(string username)
        {
            LoginCred user = null;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string sql = @"SELECT Username, Password FROM Shopper WHERE Username = '" + username + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    user = new LoginCred()
                    {
                        Username = (string)reader["Username"],
                        Password = (string)reader["Password"]
                    };
                }
            }
            return user;
        }
        public static string GetShopperName(string SessionId)
        {
            string FullName = "";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string sql = @"SELECT FirstName, LastName FROM Shopper WHERE SessionId = '" + SessionId + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    {
                        FullName = (string)reader["FirstName"];
                        FullName = FullName + " " + (string)reader["LastName"];
                    };
                }
            }
            return FullName;
        }
        public static int GetShopperId (string SessionId)
        {
            int Id = 0;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string sql = @"SELECT UserId FROM Shopper WHERE SessionId = '" + SessionId + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    {
                        Id = (int)reader["UserId"];
                    };
                }
            }
            return Id;
        }
    }
}