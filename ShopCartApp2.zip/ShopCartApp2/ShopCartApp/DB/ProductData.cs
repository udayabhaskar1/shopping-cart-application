﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ShopCartApp.Models;

namespace ShopCartApp.DB
{
    public class ProductData : Data
    {
        public static List<ProductModel> GetProductDetails()
        {
            //Product product = null;
            List<ProductModel> products = new List<ProductModel>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql = @"SELECT ProductId, ProductName, ProductDesc, ProductPrice, ProductImageLink from Product";
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ProductModel product = new ProductModel()
                    {
                        ProductId = (int)reader["ProductId"],
                        ProductName = (string)reader["ProductName"],
                        ProductDesc = (string)reader["ProductDesc"],
                        ProductPrice = (double)reader["ProductPrice"],
                        ProductImageLink = (string)reader["ProductImageLink"]
                    };
                    products.Add(product);
                }
            }
            return products;
        }
        public static int GetCartSize()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                int cnt = 0;

                string sql = @"SELECT SUM(Quantity) as cnt from Cart";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    object inp = reader["cnt"];
                    int.TryParse(inp.ToString(), out cnt);
                }
                return cnt;
            }
        }
        public static ProductBundle GetProductBundle()
        {
            return new ProductBundle()
            {
                Products = GetProductDetails(),
                CartSize = GetCartSize()
            };
        }
        public static void AddItemToCart(int prodId)
        {
            string SessionId = HttpContext.Current.Request["SessionID"];
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                int qty = 0;
                conn.Open();
                string qtysql = @"Select Quantity from Cart where ProductId=@ProductId";
                SqlCommand cmd = new SqlCommand(qtysql, conn);
                cmd.Parameters.AddWithValue("@ProductId", prodId);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    qty = (int)reader["Quantity"];
                }
                reader.Close();

                ++qty;

                string sql = @"INSERT INTO Cart(ProductId, SessionId, Quantity) values(@ProductId, @SessionId, @Qty)";
                if (qty > 1)
                {
                    sql = "UPDATE Cart SET Quantity=@Qty where ProductId=@ProductId";
                }

                cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ProductId", prodId);
                cmd.Parameters.AddWithValue("@SessionId", SessionId);
                cmd.Parameters.AddWithValue("@Qty", qty);
                cmd.ExecuteNonQuery();
            }
        }
    }
}