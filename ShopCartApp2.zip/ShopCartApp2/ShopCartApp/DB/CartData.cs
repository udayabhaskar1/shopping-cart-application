﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ShopCartApp.Models;

namespace ShopCartApp.DB
{
    public class CartData : Data
    {
        public static List<CartModel> GetCartDetails()
        {
            List<CartModel> carts = new List<CartModel>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql = @"SELECT p.ProductId, p.productName, p.ProductDesc, p.ProductPrice, c.Quantity FROM Cart c, Product p where c.ProductId=p.ProductId";
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ProductModel product = new ProductModel()
                    {
                        ProductId = (int)reader["ProductId"],
                        ProductName = (string)reader["ProductName"],
                        ProductDesc = (string)reader["ProductDesc"],
                        ProductPrice = (double)reader["ProductPrice"]
                    };
                    CartModel cart = new CartModel()
                    {
                        Quantity = (int)reader["Quantity"],
                        ProductId = product.ProductId,
                        Product = product
                    };
                    carts.Add(cart);
                }
            }
            return carts;
        }
        public static void UpdateCart(int qty, int prodId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string sql = @"Update Cart set Quantity=@qty where ProductId=@prodId";
                if (qty == 0)
                {
                    sql = @"Delete from Cart where ProductId=@prodId";
                }
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@qty", qty);
                cmd.Parameters.AddWithValue("@prodId", prodId);
                cmd.ExecuteNonQuery();

            }
        }
        public static void EmptyCart(string SessionId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string cmdText2 = @"DELETE FROM Cart WHERE SessionId ='" + SessionId + "'";
                SqlCommand cmd2 = new SqlCommand(cmdText2, conn);
                cmd2.ExecuteNonQuery();
            }
        }
    }
}