﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectCA.DB
{
    public class Data
    {
        public static string connectionString = "Data Source=DESKTOP-07V9JK1;Initial Catalog=ShopCart;Integrated Security=True";
              
    }
}