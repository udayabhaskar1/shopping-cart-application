﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjectCA.Models;
using ProjectCA.DB;

namespace ProjectCA.Controllers
{
    public class CartController : Controller
    {
        // GET: Cart
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewCart()
        {
            List<Cart> carts = CartData.GetCartDetails();
            ViewData["carts"] = carts;
            return View();
        }

        public ActionResult UpdateQty(int qty, int prodId)
        {
            CartData.UpdateCart(qty, prodId);
            return RedirectToAction("ViewCart");
        }
    }
}