﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjectCA.Models;
using ProjectCA.DB;
using System.Diagnostics;

namespace ProjectCA.Controllers
{
    public class GalleryController : Controller
    {
        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewGallery()
        {

            //List<Product> products = ProductData.GetProductDetailsByProductId();
            //Debug.WriteLine(product.ProductName);

            ViewData["productbundle"] = ProductData.GetProductBundle();
            return View();
        }

        public ActionResult AddItem(int id)
        {
            ProductData.AddItemToCart(id);
            return RedirectToAction("ViewGallery");
        }
         
       
    }
}