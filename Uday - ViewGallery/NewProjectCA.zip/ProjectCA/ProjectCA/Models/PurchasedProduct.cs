﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectCA.Models
{
    public class PurchasedProduct
    {
        public string ActCode { get; set; }
        public int ProductId { get; set; }
        public string UserId { get; set; }
        public long PurchasedDate { get; set; }
    }
}